
// ----------------------
$('#hamburger').click(function() {
    $('.hamburger_menu').addClass('myClass');
  });
  $('.your_class').click(function() {
    $('.hamburger_menu').addClass('yourclass');
  });
  
  

// Alignment issues fix
// Add content to projects 
// download resume 
// make contact us page working
// effect typewriting
// hamburger menu not working

// regex - regular expressions